<?php

namespace Studenciak\StudentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class StudenciakBundle extends Bundle
{
}
